data = load ("explicit.txt");
p = size(data);
n = p(1,2);
start = 1/(2*(n-2));
x = linspace(start,1-start,n-2);

y = [0, x, 1];
plot(y,data,'*',"color",'r', "linewidth", 12);
title('Temperature variation along length');
xlabel("Length");
ylabel("Temperature in degrees Centigrade");
set(gca, "linewidth", 4, "fontsize", 14)
grid on;