#include <iostream>
#include <math.h>
#include <fstream>

using namespace std;
const int n = 10;           // No. of finite volumes in which the domain is divided 

int main()
{
    double T[n] = {};
    double Tnew[n] = {};
    double k = 1.0;         // Thermal conductivity of bar
    double rho = 1.0;       // Density of bar           
    double cp = 1.0;        // Specific heat of bar     
    double r = k / (rho * cp);
    double err = 0;
    double length = 1.0;    // Length of bar       
    double dx = length / (double) n;
    double dt = 0.01;       // Value should be taken by keeping in mind about CFL number 
    double T_left = 0;      // Left most temperature of the bar = 0 degrees   
    double T_right = 100;   // Right most temperature of the bar = 100 degrees
    r = r * dt / (dx * dx);
    // Declaration of arrays to solve using Tri-diagonal matrix // 
    double a[n] = {}; double b[n] = {}; double c[n] = {}; double d[n] = {};
    double p[n] = {}; double q[n] = {};
    
    /* Off-diagonal elements population*/
    for (int i = 1; i < n - 1; i++)
    {
        b[i] = r;
        c[i] = r;
    }
    b[n - 1] = 0; c[0] = 0; b[0] = r; c[n - 1] = r; 

    /* Diagonal elements*/
    a[0] = 1 + (3 * r);     a[n - 1] = 1 + (3 * r);
    for (int i = 1; i < n - 1; i++)
    {
        a[i] = 1 + (2 * r);
    }
    do {
        for (int i = 0; i < n; i++)
        {
            T[i] = Tnew[i];
        }

        /* RHS terms*/
        d[0] = 2 * r * T_left + T[0];
        d[n - 1] = 2 * r * T_right + T[n - 1];
        for (int i = 1; i < n - 1; i++)
        {
            d[i] = T[i];
        }

        p[0] = b[0] / a[0];
        q[0] = d[0] / a[0];

        // Iteration terms or forward substitution //
        for (int i = 1; i < n; i++)
        {
            p[i] = b[i] / (a[i] - (c[i] * p[i - 1]));
            q[i] = (d[i] + (c[i] * q[i - 1])) / (a[i] - (c[i] * p[i - 1]));
        }
        Tnew[n - 1] = q[n - 1];
        // Backward substittuion //
        for (int j = n - 1; j > 0; j--)
        {
            Tnew[j - 1] = p[j - 1] * Tnew[j] + q[j - 1];
        }
        err = 0;
        for (int i = 0; i < n; i++)
        {
            err = err + (Tnew[i] - T[i]) * (Tnew[i] - T[i]);
        }
        cout << err << endl;
    } while (err > 1e-3);

    double T_time[n + 2] = {};
    T_time[0] = T_left;
    T_time[n+1] = T_right;

    for (int i = 0; i < n; i++)
    {
        T_time[i + 1] = Tnew[i];
    }
    /*Writing to a file*/
    ofstream myfile;
    myfile.open ("implicit.txt");
    for (int i = 0; i < n+2; i++)
    {
        myfile << T_time[i] << " ";
    }
    myfile.close();
} 